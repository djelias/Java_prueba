package com.ba.fondoinversion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioConsultaClienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
